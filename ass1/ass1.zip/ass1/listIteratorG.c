/* listIteratorG.c ... Generic List Iterator implementation
   Written by .... 

/* 
    You need to submit ONLY this file.... 

*/

#include <stdlib.h>
#include <stdio.h>
#include <assert.h>
#include "listIteratorG.h"

typedef struct Node {

  // implement struct here .. 

} Node;

typedef struct IteratorGRep {

  // implement struct here .. 

} IteratorGRep;


/*

  Your  functions here .... 


 */


// --------------------------------------





